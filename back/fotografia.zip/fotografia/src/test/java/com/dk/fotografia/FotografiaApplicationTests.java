package com.dk.fotografia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FotografiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
