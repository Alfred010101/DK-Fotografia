package com.dk.fotografia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FotografiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FotografiaApplication.class, args);
	}

}
